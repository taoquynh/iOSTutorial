//
//  File.swift
//  iOSControl
//
//  Created by Tào Quỳnh on 4/22/19.
//  Copyright © 2019 Tào Quỳnh . All rights reserved.
//

import Foundation

extension Notification.Name{
   static let notificationNamePost = Notification.Name(rawValue: "Notification.post")
}
